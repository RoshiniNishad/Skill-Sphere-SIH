import Employee from '../../models/userProfileModel/employeeModel.js'; // Import Employee model
import fs from 'fs'; // File system for saving PDFs
import path from 'path'; // Path utilities
// import { PDFDocument } from 'pdf-lib'; // PDF generation library
import jwt from 'jsonwebtoken';
import PDFDocument from "pdfkit";
import puppeteer from 'puppeteer';
import multer from 'multer';


export const getResume = async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
        console.error("Authentication token is missing");
        return res.status(401).json({ message: 'Authentication token is missing' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    const employee = await Employee.findOne({userId});
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    const resume = employee.resumeLink;
    res.status(200).json(resume);
  } catch (error) {
    res.status(500).json({ message: 'Error updating resume', error });
  }

};

// Create Resume
const createResume = async (userId) => {
  try {
    
    const employee = await Employee.findOne({userId});
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    const resume = employee.createResume();
    await Employee.updateOne({userId},{"resume":resume});
    return resume;
  } catch (error) {
return {};
}
};

// Update Resume
export const updateResume = async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
        console.error("Authentication token is missing");
        return res.status(401).json({ message: 'Authentication token is missing' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    const employee = await Employee.findOne({userId});
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    Object.assign(employee, req.body);
    await employee.save();

    const resume = employee.createResume();
    res.status(200).json(resume);
  } catch (error) {
    res.status(500).json({ message: 'Error updating resume', error });
  }
};

// Set up storage configuration for multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Define the directory where the file will be saved
    const dirPath = path.join("uploads", "resumes", "pdf");
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true }); // Create the directory if it doesn't exist
    }
    cb(null, dirPath); // Set the destination for the file
  },
  filename: function (req, file, cb) {
    // Generate a unique filename (e.g., using the employee's ID and original file name)
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return cb(new Error('Authentication token is missing'), null);
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;
    
    Employee.findOne({ userId }).then(employee => {
      const fileExtension = path.extname(file.originalname); // Get file extension
      const filename = `resume_${employee._id}${fileExtension}`;
      cb(null, filename); // Set the filename
    }).catch(err => {
      cb(err, null);
    });
  }
});

// Initialize multer with the storage configuration
const upload = multer({ storage: storage });

// Upload Resume - Use multer middleware
export const uploadResume = async (req, res) => {
  try {
    // Middleware for file upload
    upload.single('resume')(req, res, async (err) => {
      if (err) {
        console.error('Error in file upload:', err);
        return res.status(400).json({ message: 'Error in file upload', error: err.message });
      }

      // Ensure file is uploaded
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      // Extract the token from the Authorization header
      const token = req.header('Authorization')?.replace('Bearer ', '');
      if (!token) {
        console.error("Authentication token is missing");
        return res.status(401).json({ message: 'Authentication token is missing' });
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const userId = decoded.id;

      // Find the employee in the database
      const employee = await Employee.findOne({ userId });
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      // Delete existing resume file
      if (employee.resumeLink) {
        try {
          fs.unlinkSync(employee.resumeLink);
        } catch (err) {
          console.error('Error deleting existing resume file:', err);
        }
      }

      // Save the path to the uploaded resume in the employee document
      employee.resumeLink = req.file.path; // Store the path to the uploaded resume file

      // Save the updated employee record
      await employee.save();

      // Send the response
      res.status(200).json({ message: 'Resume uploaded successfully', resumePath: req.file.path });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error uploading resume', error });
  }
};


export const convertHTMLToPDFAndStore = async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      console.error("Authentication token is missing");
      return res.status(401).json({ message: 'Authentication token is missing' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    const employee = await Employee.findOne({ userId });
    let resume;
    if (!employee) return res.status(404).json({ message: 'Employee not found' });
    if (!employee.resume) {resume = createResume(userId)}
    else {resume = employee.resume};

    // Render HTML with full resume data (you can modify the rendering as per your need)
    const html = `
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${resume.personalInfo.headline} - Resume</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
          }
          .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border:1px solid black;
          }
          h1, h2 {
            text-align: center;
            color: #007bff;
          }
          h2 {
            font-size: 20px;
            margin-top: 30px;
          }
          .section {
            margin-bottom: 20px;
          }
          .section-title {
            font-weight: bold;
            font-size: 18px;
          }
          .content {
            margin-left: 20px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>${resume.personalInfo.headline}</h1>
          <p style="text-align: center;"><strong>${resume.personalInfo.bio}</strong></p>
          <p style="text-align: center;">Email: ${resume.personalInfo.email}</p>
          <p style="text-align: center;">Phone: ${resume.personalInfo.phone}</p>
          <p style="text-align: center;">Location: ${resume.personalInfo.location}</p>
          <p style="text-align: center;">Availability: ${resume.personalInfo.availability}</p>

          <!-- Education Section -->
          <div class="section">
            <h2 class="section-title">Education</h2>
            <div class="content">
              ${resume.education.map(edu => `
                <p><strong>${edu.degree}</strong>, ${edu.institution}</p>
                <p>${new Date(edu.startDate).toLocaleDateString()} - ${edu.endDate ? new Date(edu.endDate).toLocaleDateString() : 'Present'}</p>
                <p>${edu.description}</p>
                <hr>
              `).join('')}
            </div>
          </div>

          <!-- Skills Section -->
          <div class="section">
            <h2 class="section-title">Skills</h2>
            <div class="content">
              <p>${resume.skills.join(', ')}</p>
            </div>
          </div>

          <!-- Experience Section -->
          <div class="section">
            <h2 class="section-title">Experience</h2>
            <div class="content">
              ${resume.experienceDetails.map(exp => `
                <p><strong>${exp.position}</strong> at ${exp.company}</p>
                <p>${new Date(exp.startDate).toLocaleDateString()} - ${exp.endDate ? new Date(exp.endDate).toLocaleDateString() : 'Present'}</p>
                <p>${exp.description}</p>
                <hr>
              `).join('')}
            </div>
          </div>

          <!-- Career Goals Section -->
          <div class="section">
            <h2 class="section-title">Career Goals</h2>
            <div class="content">
              <p>${resume.careerGoals}</p>
            </div>
          </div>

          <!-- Contact Section -->
          <div class="section">
            <h2 class="section-title">Contact</h2>
            <div class="content">
              <p>${resume.contact}</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    // Path for saving the generated PDF
    const dirPath = path.join("uploads/resumes", 'pdf');
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath); // Create the directory if it doesn't exist
    }

    const pdfFilePath = path.join(dirPath, `resume_${employee._id}.pdf`);
    
    // Generate PDF from HTML using Puppeteer
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.setContent(html);
    await page.pdf({ path: pdfFilePath, format: 'A4' });
    await browser.close();

    // Save the file path in the employee's resume field
    employee.resumeLink = pdfFilePath;
    await employee.save();

    // Send back the download link to the client
    res.status(200).json({ message: 'Resume PDF generated and saved successfully', resumelink: pdfFilePath });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error generating resume PDF', error });
  }
};