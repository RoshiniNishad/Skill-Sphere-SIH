import React from "react";

const Footer = () => {
  return (
    <footer className="bg-green-900 text-white py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Column 1: Brand and Address */}
          <div>
            <h4 className="text-lg font-bold mb-4">Job Stock</h4>
            <p className="text-sm leading-relaxed">
              Collins Street West, Victoria, New Market Road <br />
              Australia GHR12456.
            </p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-white hover:text-green-400">
                <i className="fab fa-facebook text-lg"></i>
              </a>
              <a href="#" className="text-white hover:text-green-400">
                <i className="fab fa-twitter text-lg"></i>
              </a>
              <a href="#" className="text-white hover:text-green-400">
                <i className="fab fa-instagram text-lg"></i>
              </a>
              <a href="#" className="text-white hover:text-green-400">
                <i className="fab fa-linkedin text-lg"></i>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">For Clients</h4>
            <ul className="space-y-2 text-sm">
              <li className="hover:text-green-400 cursor-pointer">Talent Marketplace</li>
              <li className="hover:text-green-400 cursor-pointer">Direct Contracts</li>
              <li className="hover:text-green-400 cursor-pointer">Hire Worldwide</li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Download Apps</h4>
            <button className="bg-white text-green-900 px-4 py-2 rounded-lg mb-2 hover:bg-green-400 hover:text-white transition duration-200">
              Get on Google Play
            </button>
            <br />
            <button className="bg-white text-green-900 px-4 py-2 rounded-lg hover:bg-green-400 hover:text-white transition duration-200">
              Download on App Store
            </button>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Subscribe to Our Newsletter</h4>
            <p className="text-sm leading-relaxed mb-4">
              Stay updated with the latest job postings and internship opportunities.
            </p>
            <form className="flex flex-col space-y-4">
              <input
                type="email"
                placeholder="Enter your email"
                className="px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400"
              />
              <button
                type="submit"
                className="bg-green-400 text-white px-4 py-2 rounded-lg hover:bg-green-500 transition duration-200"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <p className="text-center text-sm mt-10 border-t border-green-700 pt-6">
          © 2024 - Skill Sphere . All Rights Reserved
        </p>
      </div>
    </footer>
  );
};

export default Footer;
