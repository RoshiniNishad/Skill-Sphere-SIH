import React from "react";

const TalentsSection = () => {
  const talents = [
    {
      id: 1,
      name: "Barbara T. Jean",
      role: "Sr. Web Designer",
      rate: "$70/H",
      experience: "5 Years exp.",
      rating: 4.6,
      img: "src/assets/Rev1.webp",
    },
    {
      id: 2,
      name: "Linda D. Strong",
      role: "Front-End Developer",
      rate: "$80/H",
      experience: "7 Years exp.",
      rating: 4.7,
      img: "src/assets/Rev2.jpeg",
    },
    {
      id: 3,
      name: "Marylyn A. Jefferson",
      role: "Shopify Expert",
      rate: "$65/H",
      experience: "4 Years exp.",
      rating: 4.5,
      img: "src/assets/Rev3.jpeg",
    },
    {
      id: 4,
      name: "Edward K. Buckler",
      role: "WordPress Developer",
      rate: "$60/H",
      experience: "3 Years exp.",
      rating: 4.6,
      img: "src/assets/Rev4.jpeg",
    },
    {
      id: 5,
      name: "Howard S. Lopez",
      role: "Magento Developer",
      rate: "$75/H",
      experience: "5 Years exp.",
      rating: 4.8,
      img: "src/assets/Rev3.jpeg",
    },
    {
      id: 6,
      name: "Frank T. Reeves",
      role: "Sr. UI/UX Designer",
      rate: "$80/H",
      experience: "7 Years exp.",
      rating: 4.9,
      img: "src/assets/Rev2.jpeg",
    },
    {
      id: 7,
      name: "Joseph R. Marshall",
      role: "Laravel Developer",
      rate: "$65/H",
      experience: "4.5 Years exp.",
      rating: 4.6,
      img: "src/assets/Rev4.jpeg",
    },
    {
      id: 8,
      name: "Kr. Dhannajay Preet",
      role: "Sr. Front-End Developer",
      rate: "$65/H",
      experience: "4 Years exp.",
      rating: 4.7,
      img: "src/assets/Rev1.webp",
    },
  ];

  return (
    <section className="bg-gray-50 py-10">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-6 text-green-700 animate-fade-in">
          Hire Talents & Experts
        </h2>
        <p className="text-center text-gray-600 mb-10 animate-slide-in">
          Find skilled professionals to meet your project needs and elevate your business.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {talents.map((talent) => (
            <div
              key={talent.id}
              className="bg-gradient-to-br from-white to-green-200 shadow-lg rounded-lg p-6 text-center hover:shadow-2xl transform transition-transform duration-300 hover:-translate-y-2 animate-fade-in"
            >
              <img
                src={talent.img}
                alt={talent.name}
                className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-green-100 shadow-md hover:shadow-lg transition-shadow duration-300"
              />
              <h3 className="text-xl font-semibold text-green-900">{talent.name}</h3>
              <p className="text-green-700">{talent.role}</p>
              <p className="text-green-600">{talent.rate} · {talent.experience}</p>
              <div className="text-yellow-500 mt-2">
                {"⭐".repeat(Math.floor(talent.rating))}{" "}
                {talent.rating % 1 !== 0 && "⭐"}
              </div>
              <div className="mt-4 flex justify-between gap-2">
                <button className="text-green-700 border border-green-600 px-4 py-1 rounded hover:bg-green-700 hover:text-white transition-all duration-300">
                  Message
                </button>
                <button className="bg-green-700 text-white px-4 py-1 rounded hover:bg-green-800 transition-all duration-300">
                  View Detail
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TalentsSection;
