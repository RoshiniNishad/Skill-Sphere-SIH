import React, { useState, useEffect } from "react";
import axios from "axios";

const categories = [
  "Most Popular",
  "IIT Madras Pravartak Certified",
  "Programming",
  "Business & Management",
  "Core Engineering",
  "Data Science",
  "Design",
  "Artificial Intelligence",
  "Creative Arts",
  "Language",
  "Career Development",
  "Architecture",
];

const CourseGrid = () => {
  const [courses, setCourses] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1); // Pagination control

  const fetchCourses = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/courses`, {
        params: { page }, // Pass the page number for pagination
      });
      setCourses((prevCourses) => [...prevCourses, ...response.data.courses]);
    } catch (err) {
      console.error("Error fetching courses:", err);
      setError("Failed to fetch courses.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleScroll = () => {
    if (
      window.innerHeight + document.documentElement.scrollTop >=
      document.documentElement.offsetHeight - 100
    ) {
      setPage((prevPage) => prevPage + 1); // Increment page number to fetch more courses
    }
  };

  useEffect(() => {
    fetchCourses(); // Fetch courses on component mount and when the page changes
  }, [page]);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-green-50 flex mt-24">
      {/* Sidebar for Categories */}
      <aside className="w-1/4 bg-white shadow-lg p-4 h-screen sticky top-0">
        <h2 className="text-lg font-bold text-green-700 mb-4">Categories</h2>
        <ul className="space-y-2">
          {categories.map((category, index) => (
            <li
              key={index}
              className="text-green-600 font-semibold hover:bg-green-100 hover:scale-105 transition-transform transform hover:shadow-md cursor-pointer p-2 rounded"
            >
              {category}
            </li>
          ))}
        </ul>
      </aside>

      {/* Main Content Section */}
      <div className="w-3/4 overflow-auto">
        <header className="text-center py-8 bg-white shadow-md mb-4 sticky top-0 z-10">
          <h1 className="text-3xl font-bold text-green-700">Certifications</h1>
          <p className="text-lg text-green-600 mt-2">
            Explore certification courses for your internship job journey!
          </p>
        </header>

        {/* Course Grid Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
          {courses.map((course, index) => (
            <div
              key={`${course.title}-${index}`}
              className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform transform hover:scale-105 hover:shadow-xl"
            >
              {/* Image that covers the whole box */}
              <div className="relative h-44">
                <img
                  src={course.image || "https://via.placeholder.com/400?text=Course+Image"}
                  alt={course.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Overlay Content */}
              <div className="p-4">
                <h3 className="text-lg font-bold text-green-700">
                  {course.title}
                </h3>
                <p className="text-sm text-green-600">{course.duration}</p>
                <p className="text-sm text-green-600">
                  <span className="font-semibold">{course.rating}</span> ⭐ |{" "}
                  {course.learners} learners
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Loading Indicator */}
        {isLoading && (
          <div className="text-center mt-5 text-green-600">
            Loading more certification courses...
          </div>
        )}

        {error && <div className="text-center mt-5 text-red-600">{error}</div>}
      </div>
    </div>
  );
};

export default CourseGrid;
