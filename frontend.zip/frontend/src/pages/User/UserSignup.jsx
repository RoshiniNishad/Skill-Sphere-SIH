import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext"; // Import useAuth from AuthContext
import signupImg from "../../assets/SignupImg.jpg";
import Header from "../../components/Header";

const UserSignup = () => {
  const [firstName, setfirstName] = useState("");
  const [lastName, setlastName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [location, setLocation] = useState("");
  const [role, setRole] = useState("employee");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { login } = useAuth(); // Access login function from AuthContext

  const handleUserSignup = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    // Validate if passwords match
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      setLoading(false);
      return;
    }

    try {
      const response = await axios.post(
        import.meta.env.VITE_BACKEND_URL + "/api/auth/user/signup",
        {
          firstName,
          lastName,
          username,
          email,
          phoneNumber,
          location,
          role,
          password,
        }
      );

      const { token, user, message } = response.data;

      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));

      login();
      navigate("/");
    } catch (err) {
      // More robust error handling
      if (err.response?.status === 400) {
        setError(err.response?.data?.message || "Bad request. Please check your input.");
      } else {
        setError("Something went wrong. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center bg-gradient-to-r from-blue-100 via-purple-100 to-green-100">
      <Header />
      <div className="max-w-4xl bg-white rounded-lg shadow-lg p-6 grid grid-cols-1 md:grid-cols-2 gap-4 text-black m-10 relative top-24 h-screen">
        {/* Left Section */}
        <div className="text-black flex flex-col justify-center">
          <h1 className="text-4xl text-green-600 font-bold mb-2">Create an Account</h1>
          <p className="text-black text-sm mb-6">
            Join our platform and start your journey today. <br />
            <span className="italic text-black">Let's build something amazing together.</span>
          </p>
          <form className="space-y-4" onSubmit={handleUserSignup}>
            {/* Full Name */}
            <div>
              <label htmlFor="firstName" className="block text-sm font-medium text-black">
                First Name
              </label>
              <input
                type="text"
                id="firstName"
                value={firstName}
                onChange={(e) => setfirstName(e.target.value)}
                placeholder="Enter your full name"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
                required
              />
            </div>
            {/* Full Name */}
            <div>
              <label htmlFor="lastName" className="block text-sm font-medium text-black">
                Last Name
              </label>
              <input
                type="text"
                id="lastName"
                value={lastName}
                onChange={(e) => setlastName(e.target.value)}
                placeholder="Enter your last name"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
                required
              />
            </div>

            {/* Username */}
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-black">
                Username
              </label>
              <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter a username"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-black">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email address"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
                required
              />
            </div>

            {/* Phone Number */}
            <div>
              <label htmlFor="phoneNumber" className="block text-sm font-medium text-black">
                Phone Number
              </label>
              <input
                type="tel"
                id="phoneNumber"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="Enter your phone number"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
              />
            </div>

            {/* Location */}
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-black">
                Location
              </label>
              <input
                type="text"
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Enter your location"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
              />
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-black">
                Password
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter a password"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
                required
              />
            </div>

            {/* Confirm Password */}
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-black">
                Confirm Password
              </label>
              <input
                type="password"
                id="confirmPassword"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm your password"
                className="mt-1 w-full px-4 py-2 bg-gray-200 text-black rounded-md placeholder:text-gray-500"
                required
              />
            </div>

            {/* Role Selection */}
            <div>
              <label className="block text-sm font-medium text-black mb-2">Select Role</label>
              <div className="flex space-x-4 mb-6">
                <button
                  type="button"
                  onClick={() => setRole("employee")}
                  className={`py-2 px-4 text-white rounded-md ${role === "employee" ? "bg-black" : "bg-green-600"}`}
                >
                  Employee
                </button>
                <button
                  type="button"
                  onClick={() => setRole("employer")}
                  className={`py-2 px-4 text-white rounded-md ${role === "employer" ? "bg-black" : "bg-green-600"}`}
                >
                  Employer
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className={`w-full py-2 px-4 ${loading ? "bg-gray-500" : "bg-green-600 hover:bg-yellow-600"} text-black font-semibold rounded-md focus:ring`}
              disabled={loading}
            >
              {loading ? "Signing up..." : "Sign Up"}
            </button>
          </form>

          {error && <p className="mt-4 text-red-500 text-sm">{error}</p>}

          {/* Log In Link */}
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              Already have an account?{" "}
              <Link to="/user/login" className="text-green-600 font-medium hover:underline">
                Log In
              </Link>
            </p>
          </div>
        </div>

        {/* Right Section */}
        <div className="hidden md:flex md:justify-center md:items-center">
          <img src={signupImg} alt="Signup illustration" className="rounded-md" />
        </div>
      </div>
    </div>
  );
};

export default UserSignup;
