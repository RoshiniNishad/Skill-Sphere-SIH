import React from "react";
import JobCard from "../../components/JobCard.jsx";
import EmployerSidebar from "../../components/EmployerSidebar.jsx";
import { FaHome } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
const EmployerCertifications = () => {
    const certifications = [
        {
            title: "AWS Certification",
            company: "Amazon",
            applicants: 320,
            postedDate: "17 Oct 2023",
            expiryDate: "17 Jan 2024",
        },
        {
            title: "Google Cloud Certification",
            company: "Google",
            applicants: 210,
            postedDate: "25 Oct 2023",
            expiryDate: "25 Feb 2024",
        },
        {
            title: "Google Cloud Certification",
            company: "Google",
            applicants: 210,
            postedDate: "25 Oct 2023",
            expiryDate: "25 Feb 2024",
        },
        {
            title: "Google Cloud Certification",
            company: "Google",
            applicants: 210,
            postedDate: "25 Oct 2023",
            expiryDate: "25 Feb 2024",
        },
        {
            title: "Google Cloud Certification",
            company: "Google",
            applicants: 210,
            postedDate: "25 Oct 2023",
            expiryDate: "25 Feb 2024",
        },
        {
            title: "Google Cloud Certification",
            company: "Google",
            applicants: 210,
            postedDate: "25 Oct 2023",
            expiryDate: "25 Feb 2024",
        },
        {
            title: "Google Cloud Certification",
            company: "Google",
            applicants: 210,
            postedDate: "25 Oct 2023",
            expiryDate: "25 Feb 2024",
        },
        {
            title: "Google Cloud Certification",
            company: "Google",
            applicants: 210,
            postedDate: "25 Oct 2023",
            expiryDate: "25 Feb 2024",
        },
    ];
    const navigate = useNavigate();

    return (
        <div className="flex bg-gray-100 h-screen">
            <EmployerSidebar />
            <div className="flex p-5 flex-col w-full h-screen bg-gray-50 overflow-y-auto">
                <h1 className="text-2xl font-bold mb-4">Manage Certifications</h1>
                <div className="mt-3">
                    {certifications.map((certification, index) => (
                        <JobCard key={index} {...certification} />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default EmployerCertifications;
