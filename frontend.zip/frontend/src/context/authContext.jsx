import React, { createContext, useContext, useState, useEffect } from "react";
import { jwtDecode } from "jwt-decode";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [role, setRole] = useState(null);
    const [token, setToken] = useState(null);

    // Check if the user is logged in and validate token on app load
    useEffect(() => {
        const storedToken = localStorage.getItem("token");

        if (storedToken) {
            try {
                const decodedToken = jwtDecode(storedToken);
                // Check if token is expired
                if (decodedToken.exp * 1000 > Date.now()) {
                    setIsLoggedIn(true);
                    setToken(storedToken);
                    setRole(decodedToken.role); // Assuming role is stored in the token payload
                } else {
                    logout(); // Token expired, logout the user
                }
            } catch (error) {
                console.error("Invalid token:", error);
                logout(); // Invalid token, logout the user
            }
        }
    }, []);

    // Login function
    const login = (jwtToken) => {
        try {
            const decodedToken = jwtDecode(jwtToken);
            setIsLoggedIn(true);
            setToken(jwtToken);
            setRole(decodedToken.role); // Set role from decoded token

            // Store token and role in localStorage
            localStorage.setItem("token", jwtToken);
            localStorage.setItem("role", decodedToken.role);
        } catch (error) {
            console.error("Error decoding token:", error);
        }
    };

    // Logout function
    const logout = () => {
        // Remove token and role from localStorage
        localStorage.removeItem("token");
        localStorage.removeItem("role");
        // Reset states
        setIsLoggedIn(false);
        setRole(null);
        setToken(null);
    };

    return (
        <AuthContext.Provider
            value={{
                isLoggedIn,
                token,
                role,
                login,
                logout,
                setIsLoggedIn,
                setRole: (newRole) => {
                    setRole(newRole);
                    localStorage.setItem("role", newRole); // Update role in localStorage
                },
            }}
        >
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
